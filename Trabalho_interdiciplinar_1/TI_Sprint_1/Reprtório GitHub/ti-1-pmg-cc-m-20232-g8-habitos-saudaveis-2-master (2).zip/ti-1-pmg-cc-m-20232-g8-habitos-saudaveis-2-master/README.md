[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=11816621&assignment_repo_type=AssignmentRepo)
# Mea Health
   * Nesse trabalho, o problema a ser abordado será, Dificuldades para ter hábitos saudáveis, este problema é uma pauta muito presente na atualidade, envolvedo um grande público alvo que apresenta dificuldades para adquirir hábitos saudáveis. Diante dessas dificuldades e após a análise e entrevistas com diferentes personas, o grupo tende a desenvolver soluções para atender a diferentes realidades afim de ajudar o cliente a superar suas dificuldades.

## Alunos integrantes da equipe

* Ana Sara Nunes Pereira
* Gabriel Chaves Mendes
* Gabriela de Assis dos Reis
* Henrique Augusto de oliveira marcelino
* Leonardo Amaral Passos Figueiredo
* Lucca Cenisio Martins
* Paulo Henrique Lopes de Paula

## Professores responsáveis

* Ilo Amy Saldanha Rivero
* João Carlos Oliveira Caetano
* Luciana Mara Freitas Diniz
* Rommel Vieira Carneiro
 

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
