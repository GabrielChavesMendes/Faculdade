Olá professor Theldo! Envio nesta pasta, 
propriamente organizadas, as minhas atividades em atraso, 
correspondentes às guias : 11, 12, 13 e 14, 
além da atividade de preparação para a segunda avaliação , 
a PA2.

OK.
 
