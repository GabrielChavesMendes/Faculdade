Olá theldo, tudo bem? Adicionei em cada questão 3 
comentários dos elementos principais aprendidos ou notados 
enquanto as fazia.

OK.
