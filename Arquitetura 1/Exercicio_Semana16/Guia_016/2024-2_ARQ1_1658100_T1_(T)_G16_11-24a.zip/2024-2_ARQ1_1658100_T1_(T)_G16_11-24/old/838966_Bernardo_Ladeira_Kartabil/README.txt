Olá professor Theldo, tudo bem?

Eu sei que está fora do prazo das atividades, eu entendo que estou errado. Porém, quero que o senhor saiba que eu fiz alguns guias, então os anexei. Peço perdão por
minha falta de gerenciamento de tempo