Gostaria de informar que estou enviando o Guia 15 nesta tarefa, conforme combinado. Acabei esquecendo de enviá-lo no domingo passado.

Peço desculpas pela demora e agradeço pela compreensão.