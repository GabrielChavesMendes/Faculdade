Caro Theldo, me esqueci de enviar o Guia 14 dentro do prazo na última semana. Estou enviand-oo agora junto ao Guia 15.
Peço desculpas pelo atraso.