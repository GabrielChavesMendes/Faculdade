Prezado professor,
estou enviando juntamente com este guia o guia 11, mesmo que 
incompleto eu eviarei oque fui capaz de fazer.

Att, Ana Clara Lonczynski