Olá, Theldo. Tudo bem? Primeiramente, gostaria de me desculpar pelo atraso na entrega dos últimos
guias. Os últimos meses foram um pouco complicados. No início do mês passado, quebrei o polegar
e fiquei com a mão direita imobilizada devido ao uso de uma tala para recuperação, o que durou
três semanas. Estou anexando o atestado médico que comprova a situação. O documento atesta 10 dias
de afastamento, mas foi solicitado apenas para que eu pudesse refazer a prova de AEDs II em outro
período. No entanto, o tempo de recuperação se estendeu um pouco mais.

Apesar disso, segui me esforçando para manter as matérias em dia. No entanto, acabei priorizando
AEDs, pois estávamos no prazo de entrega do trabalho prático. Além disso, antes do incidente, eu
já havia me inscrito no Hackathon da PUC, evento que demandou bastante tempo e acabou contribuindo
para o atraso nas entregas.

O evento terminou este mês, e, junto com a minha equipe, conquistamos o segundo lugar na competição.
Nas próximas semanas, estarei enviando todas as atividades pendentes e poderei dedicar-me integralmente
à sua disciplina. Já preparei alguns outros guias que não constam nesta entrega. Eles deveriam
ter sido enviados na semana passada, mas acabei anexando o arquivo errado. Hoje, devido às fortes
chuvas na cidade onde moro, estou sem energia desde o fim de semana e não consigo acessar os
documentos no meu computador. Por isso, estou enviando apenas o guia 05, que estava acessível no
drive do meu notebook, e aproveito para explicar os motivos da falta das últimas tarefas.

Peço desculpas pelo transtorno e espero que seja possível compreender a situação, uma vez que
continuo presente nas aulas e comprometido em aprender e acompanhar a matéria.

Atenciosamente, João Pedro Torres.

// Ok. 